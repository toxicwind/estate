#!/usr/bin/env bash
# deploy-hatch.sh — deploy the cell-side yote-connector + CLI on the hatch cell.
# Run ON the cell as root:  bash projects/bridge/ops/deploy-hatch.sh <projects-bridge-dir>
# Idempotent. Does NOT restart the daemon (stop/start are separate, verified steps).
set -euo pipefail

SRC="${1:?usage: deploy-hatch.sh <projects-bridge-dir>}"
[ -f "$SRC/hatch/connector.py" ] || { echo "missing: $SRC/hatch/connector.py" >&2; exit 1; }
[ -f "$SRC/hatch/yote-conn" ] || { echo "missing: $SRC/hatch/yote-conn" >&2; exit 1; }

CONN_DIR="/home/hatch/workspace/yote-connector"
BIN="/home/hatch/workspace/bin/yote-conn"

mkdir -p "$CONN_DIR"
install -o root -g root -m 0640 "$SRC/hatch/connector.py" "$CONN_DIR/connector.py"
python3 -m py_compile "$CONN_DIR/connector.py"
install -o root -g root -m 0750 "$SRC/hatch/yote-conn" "$BIN"

# ownership/permission repair across bridge paths (was root:nogroup, 0660/0770/2770)
chown -R root:root "$CONN_DIR" "$BIN"
find "$CONN_DIR" -type d -exec chmod 0750 {} +
find "$CONN_DIR" -type f -name "*.py" -exec chmod 0640 {} +
[ -f "$CONN_DIR/connector.log" ] && chmod 0640 "$CONN_DIR/connector.log"
[ -f "$CONN_DIR/connector.pid" ] && chmod 0640 "$CONN_DIR/connector.pid"
chmod 0750 "$BIN"

echo "hatch deploy ok from $SRC"
ls -l "$CONN_DIR/connector.py" "$BIN"
