#!/usr/bin/env bash
# deploy-yote.sh — deploy the bridge bg exec layer on yote from a repo checkout.
# Run ON yote (via the bridge):  bash projects/bridge/ops/deploy-yote.sh [repo-root]
# Idempotent. Never touches the live WS exec server, squawk, or port 443.
set -euo pipefail

REPO="${1:-$(cd "$(dirname "$0")/../.." && pwd)}"
SRC="$REPO/projects/bridge"
LIVE_BIN="/home/toxic/sovereign/projects/bridge/bin"
CACHE="/home/toxic/.cache/bridge-bg"

for f in bg-run.py bg-status.py bg-kill.py bg-ctl.py; do
  [ -f "$SRC/bin/$f" ] || { echo "missing: $SRC/bin/$f" >&2; exit 1; }
done

for f in bg-run.py bg-status.py bg-kill.py bg-ctl.py; do
  install -o toxic -g toxic -m 0755 "$SRC/bin/$f" "$LIVE_BIN/$f"
  python3 -m py_compile "$LIVE_BIN/$f"
done

mkdir -p "$CACHE"
chown toxic:toxic "$CACHE"
chmod 0755 "$CACHE"

# direct shebang invocation must work after ownership/mode repair
"$LIVE_BIN/bg-ctl.py" list >/dev/null
echo "yote deploy ok from $REPO"
ls -l "$LIVE_BIN"/bg-*.py
