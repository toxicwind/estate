#!/usr/bin/env bash
# estate-scripts Modular Profile System - absolute, no dynamic dirname
export estate-scripts_ROOT="/home/toxic/estate-scripts"
export estate-scripts_PROFILE="${estate-scripts_PROFILE:-toxic}"
PROFILE_DIR="${estate-scripts_ROOT}/profiles/${estate-scripts_PROFILE}"
DEFAULT_DIR="${estate-scripts_ROOT}/profiles/default"
if [ -f "${PROFILE_DIR}/env.sh" ]; then
    . "${PROFILE_DIR}/env.sh"
elif [ -f "${DEFAULT_DIR}/env.sh" ]; then
    . "${DEFAULT_DIR}/env.sh"
fi
export estate-scripts_PROFILE
export estate-scripts_ROOT
