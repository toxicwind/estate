export const PROJECTS_DIR = "/home/toxic/projects";
export const estate-scripts_DIR = "/home/toxic/estate-scripts";
export const PROJECTS_ENV = "/home/toxic/projects.env";
export const COMPLETIONS_URL = "http://127.0.0.1:25100/v1/chat/completions";
export const SECRETS_FILE = "/home/toxic/.secrets";
export const SECRETS_BACKUPS = ["/home/toxic/.secrets.bak", "/home/toxic/.secrets.backup"];
