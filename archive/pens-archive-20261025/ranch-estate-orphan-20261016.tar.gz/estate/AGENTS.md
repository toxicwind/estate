# AGENTS.md — estate-scripts Control Plane (`/home/toxic/estate-scripts`)

**Role**: Core control plane & orchestration layer for the estate-scripts ecosystem.
**Stack**: TypeScript (Bun), Python, mise, pitchfork, Kafka, Qdrant, Prometheus/Grafana.
**Host**: toxic (Ryzen 7 8700F, 62 GiB DDR5, RTX 3090 24 GB).

---

## 🎯 Repository Specifics

- **Primary Entrypoints**: `src/` (generators, hal-substrate, services, mesh-front).
- **Pitchfork Daemons**: `pitchfork.toml` orchestrates services across `25xxx` ports.
- **Mise Tasks**: `mise.toml` defines local task runners and environment configurations.
- **Port SSOT**: `config/ports.env` is the single source of truth for all allocated ports.
- **Agents & Profiles**: `agents/` and `profiles/` store estate-scripts agent specs and persona definitions.

## 🔧 Hard Rules (universal)

1. **Verify live, then claim.** No "done" without `curl` / `lsof` / `nvidia-smi` / `npx tsgo --noEmit`.
2. **Fail loud.** Never `2>/dev/null`, never `|| true`. Errors are diagnostic.
3. **No commit without explicit user request.** Fork stays private under `toxicwind`.
4. **Multi-strategy.** Non-trivial work → 3+ approaches, benchmark, keep runner-up.
5. **TDD/BDD.** Failing assertion first, then fix. `npx tsgo --noEmit` for type-check.
6. **Use emergence tools first.** GHAS (`:25113`) → ast-grep (`ast-grep` binary) → Tombi for TOML.
7. **call_tool_destructive is DEFAULT for state changes.** Write/edit/modify = destructive. Read-only = inspection only.
8. **No `/dev/null`, no banner `echo`.** Both waste tokens.
   8b. **BANNED/SLOW TOOLS — do NOT use, ever:** `find`, `head`, `tail`, `/dev/null`, and system-wide `lsof`.
   - `find` over a large/full disk is slow + wasteful -> use `fd` (fast, gitignore-aware)
     or scope `du`/`fd` to a SPECIFIC directory, never the whole `/home`/`/`.
   - `head`/`tail` truncation -> read full files with the `read` tool (1M context).
   - `/dev/null` -> fail loud; never silence errors.
   - `lsof` (esp. system-wide) is INSANELY SLOW -> use INSTANT `/proc/<pid>/fd` symlink
     reads (`readlink /proc/$PID/fd/*`) to see what a process has open. Scope to known PIDs.
9. **Fix bashrc nested quote issue.** The `pi-check` alias had nested double quotes inside single quotes, causing `unexpected EOF while looking for matching '"'` errors. Use functions instead of aliases for complex commands.
10. **CUDA-aware.** RTX 3090 — validate with `nvidia-smi`. Never assume upstream defaults.
11. **Stop stacking long commands.** Sub-second probes. Reserve `60|120` for intentional jobs.
12. **No `head` truncation.** You have 1M context. Read full files. No `| head -20`.
13. **Timeout/failfast/high-frequency is FIRST-CLASS everywhere** (retry, provider-retry, worker-limits, MCP calls, scripts). NO insane monolithic timeouts — use failfast + high-frequency liveness probes + per-attempt deadlines.
14. **Dynamic `${ENV_VAR}` interpolation is first-class** in configs/scripts (settings.json, config.yml, mcpproxy config, launch scripts). Prefer `${...}` over hardcoded values.
15. **Lint + test after EVERY code change; coverage floor 82%.** Pre-existing type errors in unrelated test files do NOT block the change under review — isolate + report.
16. **BACKGROUNDING IS FIRST-CLASS.** Any op that can run long (downloads, builds, scans,
    npm/pip/apt, model fetches) MUST be launched in background (`cmd &`, capture `$!`), tracked
    by PID, and CANCELLED if it overruns a per-attempt deadline (`timeout`, `kill` on a watchdog
    loop). Never block on a monolithic synchronous command. Keep a live PID ledger.
17. **GOAL = ENDLESS TODO.** TODO.md is a CONTINUOUS improvement loop, not a finite list.
    Re-audit constantly; new findings always append; done items cycle back as deeper waves.
    No "finished" — only "next wave". Mutate TODO after every meaningful step.

---

## 🛠️ Tool Reference

### ✅ INSTALLED (use these)

| Tool        | Binary                               | Purpose                                                       |
| ----------- | ------------------------------------ | ------------------------------------------------------------- |
| `fd`        | `/usr/bin/fd`                        | Fast find (respects .gitignore)                               |
| `rg`        | `/usr/bin/rg`                        | Fast grep (respects .gitignore)                               |
| `ast-grep`  | `~/.local/share/mise/shims/ast-grep` | AST structural search/rewrite                                 |
| `eza`       | `/usr/bin/eza`                       | Modern ls (git-aware)                                         |
| `mise`      | `~/.local/bin/mise`                  | Runtime manager                                               |
| `bun`       | mise shim                            | Fast JS runtime                                               |
| `node`      | mise shim                            | JS runtime                                                    |
| `cargo`     | mise shim                            | Rust build                                                    |
| `jq`        | mise shim                            | JSON processing                                               |
| `codeshift` | `/home/toxic/projects/codeshift`     | Multi-agent codebase migration & test equivalence (local LLM) |

### ❌ NOT INSTALLED (don't use, install first if needed)

| Tool     | Install Command     | Purpose                             |
| -------- | ------------------- | ----------------------------------- |
| `tombi`  | `mise use -g tombi` | TOML toolkit                        |
| `tsgo`   | `npx tsgo`          | TypeScript type-check (use via npx) |
| `vitest` | `npx vitest`        | Test runner (use via npx)           |

### 🚫 NEVER USE (removed/confusing)

| Name | Why                                                        |
| ---- | ---------------------------------------------------------- |
| `sg` | That's SGLang, NOT ast-grep. Removed shim. Use `ast-grep`. |

---

## 📝 AST-Grep Patterns

### Rule YAML

```yaml
id: my-rule
language: typescript
rule:
  pattern: "console.log($MSG)"
fix: "logger.info($MSG)"
```

### Commands

```bash
ast-grep scan -p 'pattern' -l ts src/
ast-grep scan -p 'pattern' --rewrite 'replacement' src/
ast-grep scan -p 'pattern' --json=stream src/
ast-grep scan -p 'pattern' --interactive src/
ast-grep scan --rule rule.yaml src/
```

---

## 📡 Live-verify commands

```bash
for p in 25100 25109 25112 25115; do
  fuser -s $p/tcp 2>/dev/null && echo "✅ :$p" || echo "❌ :$p DOWN"
done

curl -s http://127.0.0.1:25100/v1/models | python3 -c "import sys,json;print(len(json.load(sys.stdin)['data']),'models')"

cd /home/toxic/projects/pi-agent/packages/ai && npx tsgo --noEmit

ast-grep scan -p 'NVIDIA_MODELS' -l ts --json=stream /home/toxic/projects/pi-agent/packages/ai/src/
```

---

## ⏱️ Timeout / Failfast / Dynamic / Env-Var (first-class, 2026-08-13)

- **Failfast + high-frequency**: every retry/timeout path uses per-attempt deadlines, failfast
  on fatal errors, and high-frequency liveness probes. No `timeout 420` monoliths.
- **Dynamic `${ENV_VAR}`**: configs and launch scripts interpolate env vars (`${NVIDIA_API_KEY}`,
  `${HOME}`, etc.). Hardcoded secrets/paths are an anti-pattern — interpolate.
- **Coverage floor 82%**: `npx vitest run --coverage --bail` after code. Lint (`biome`) + typecheck.
- See TODO Wave 5 for the worker-limit `/32` redo + timeout/failfast threading.

## 🔌 MCP / mcpproxy (estate-scripts-owned)

- **mcpproxy** is the single MCP federation gateway: `http://127.0.0.1:25109/mcp`, owned by
  estate-scripts (`pitchfork start mcpproxy` / `mise run restart-mcpproxy` -> `mcpproxy serve
--config=/home/toxic/.mcpproxy/mcp_config.json`). 43 real upstreams (ghas + 42 others).
- **pi MUST list ONLY `mcpproxy`** in `~/.pi/agent/mcp.json` (no duplicate direct `ghas`/
  `nvidia-nim` entries). All MCP tools reach pi through the proxy via `retrieve_tools`.
- **nvidia-nim is NOT an MCP server.** It is a llama-swap/estate-scripts-router **completions API**
  (OpenAI-compatible, on `:25100`). NVIDIA models are first-class via pi-agent's `nvidia`
  provider (`packages/ai/src/providers/`) -> estate-scripts-router/llama-swap, not an MCP upstream.
- **Subagents**: `config.yml` `can_spawn_subagents:true` + whitelist + `subagents.defaultModel:
opencode/hy3-free`. The `subagent` spawn tool is a LIVE-PI builtin (not callable from a
  plain assistant context) — fanout only works inside an interactive pi session.

## 🔌 Port SSOT

`/home/toxic/estate-scripts/config/ports.env` — all 25xxx, never invent.

---

---

## 📁 Repository Key Paths

- `config/ports.env` — Port SSOT
- `pitchfork.toml` — Daemon service definitions
- `mise.toml` — Task runner and tool versions
- `src/` — estate-scripts backend, mesh frontend, HAL substrate
- `agents/` — Subagent profiles and identities

## maximal-estate-scripts-agentic-audit
- **Location**: `src/maximal-estate-scripts-agentic-audit/`
- **Skill**: `skills/maximal-estate-scripts-agentic-audit/`
- **Features**: Multi-tier chained execution, ast-grep, eza, gh api code search, pattern borrowing, Bun.nanoseconds() timing, mitata benchmarks, streaming, agentic completions, multi-repo support (--repos, --users)
- **Run**: `cd src/maximal-estate-scripts-agentic-audit && bun run src/index.ts --user toxicwind --check-bun --timing`
- **Build**: `cd src/maximal-estate-scripts-agentic-audit && bun run check`
- **Tests**: `cd src/maximal-estate-scripts-agentic-audit && bun test --coverage`

## Maximal estate-scripts Agentic Audit

**Location**: `src/maximal-estate-scripts-agentic-audit/`
**Architecture**: Fully modular with 10 separate module files

### Modules
- `src/modules/types.ts` — RepoRecord, LocalAuditResult, SymlinkRecord, AuditMode
- `src/modules/constants.ts` — All file paths and URLs
- `src/modules/parser.ts` — `parseProjectsEnvSync()` parses 327 projects from projects.env
- `src/modules/git-scanner.ts` — `scanDirSync()`, `scanSymlinksSync()`, `runGit()` (execFile)
- `src/modules/secrets-scanner.ts` — `scanSecrets()`, `getSecretsRecord()` (.secrets first-class)
- `src/modules/completions.ts` — `analyzeWithCompletions()` via 25100 API
- `src/modules/autofix.ts` — `autoFix()` for broken symlinks
- `src/modules/precheck.ts` — `preCheck()` validation
- `src/modules/dataframe.ts` — `toDataFrame()` export
- `src/modules/parquet.ts` — `exportParquet()` using ParquetWriter.openFile

### Key Facts
- `localAudit()` ALWAYS scans all 327 projects from projects.env (expand-to-all-projects rule)
- `.secrets` at `/home/toxic/.secrets` is a first-class credential record
- `Bun.nanometers()` does not exist — use `performance.now()` for timing
- `ParquetWriter.openFile(schema, path)` is the correct API (not `openParquetWriter`)
- `runGit()` uses `execFile("git", args, ...)` with array args
- `scanDirSync()` adds ONE record per project directory
- All 29 tests pass across 7 test files
- Test coverage target: 86%+
- Parquet export works: `local-repos.parquet` (53KB)

### Commands
```bash
bun run start --all --precheck --parquet output/audit.parquet
bun test tests/ --coverage
bun run local --all --precheck
```
