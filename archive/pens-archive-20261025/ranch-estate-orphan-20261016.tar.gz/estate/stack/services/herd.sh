#!/usr/bin/env bash
# herd (llama-swap) direct-bind launcher — binds Go binary to 0.0.0.0:HERD_PORT (25100).
# Renamed from llama-swap.sh — project-wide herd naming, llama-swap binary kept for compatibility.
# No proxy/middleware hop. mesh-hub (25115) serves 20 GHAS /mesh/* features.
set -euo pipefail
SOV="$HOME/estate-scripts"
source "$SOV/stack/lib-ports.sh"
require_env HERD_PORT
PORT="$HERD_PORT"
BIN="$HOME/projects/estate-scripts-projects/estate-scripts-swap/build/llama-swap"
[[ -x "$BIN" ]] || { echo "herd (llama-swap) bin not found at $BIN" >&2; exit 1; }
CONF="$SOV/config/herd.yaml"
[[ -f "$CONF" ]] || CONF="$SOV/config/llama-swap.yaml"
[[ -f "$CONF" ]] || { echo "herd config not found at $CONF" >&2; exit 1; }
# Kill any existing llama-swap on this port
fuser -k "${PORT}/tcp" 2>/dev/null || true
sleep 0.3

# Launch Go binary — direct bind to 0.0.0.0:PORT (no proxy hop)
"$BIN" --config "$CONF" --listen "0.0.0.0:${PORT}" &
BPID=$!
cleanup() { kill "$BPID" 2>/dev/null || true; }
trap cleanup EXIT TERM INT

# Wait for health endpoint (max 15s)
for i in $(seq 1 40); do
  if curl -sf -m 0.3 "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1; then break; fi
  sleep 0.25
done

# Keep the script running (waits for the Go binary)
wait "$BPID"
