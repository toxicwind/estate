#!/usr/bin/env bash
# estate-scripts Tailscale Service Wrapper
exec /usr/bin/tailscaled --state=/home/toxic/estate-scripts/.state/tailscaled.state --socket=/home/toxic/estate-scripts/.state/tailscaled.sock
