#!/usr/bin/env bash
set -euo pipefail
export estate-scripts_ROOT="${estate-scripts_ROOT:-$HOME/estate-scripts}"
exec bun run "$estate-scripts_ROOT/src/deploy/ide_clients.ts"
