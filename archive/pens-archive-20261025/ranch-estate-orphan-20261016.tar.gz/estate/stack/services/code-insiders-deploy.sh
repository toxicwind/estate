#!/usr/bin/env bash
set -euo pipefail
exec bun run "${estate-scripts_ROOT:-$HOME/estate-scripts}/src/deploy/code_insiders.ts"
