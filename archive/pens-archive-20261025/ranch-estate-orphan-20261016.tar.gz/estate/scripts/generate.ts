// ============================================================================
// estate-scripts — Config Generation CLI Entry Point
// Run: bun run scripts/generate.ts
// ============================================================================

import { resolve } from "node:path";
import { generateAll } from "../src/generators/index.ts";

const root = process.env.estate-scripts_ROOT || resolve(import.meta.dir, "..");
await generateAll(root);
