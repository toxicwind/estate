#!/bin/bash
echo "=== PWD ==="
pwd
echo "=== LS ==="
ls -la target/release/gh-search-mcp
echo "=== HELP ==="
./target/release/gh-search-mcp --help
echo "=== REPRO INPUT ==="
cat repro_input.json
echo "=== RUNNING REPRO ==="
./target/release/gh-search-mcp < repro_input.json
echo "=== EXIT CODE: $? ==="
